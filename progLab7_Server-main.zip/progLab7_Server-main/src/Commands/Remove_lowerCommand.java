package Commands;

import Data.LabWork;
import Forms.MessageForm;
import Managers.*;
import ServerNet.UdpServer;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.TreeSet;

/**
 * Удаляет все элементы значение поля minimalPoint которых менее заданного в аргументе inputCommand
 */
public class Remove_lowerCommand extends AbstractCommand{
    static LinkedHashSet<Object> objectLinkedHashSet= new LinkedHashSet<>();

    public void executeCommand(Object inputObject) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(inputObject);
        Float inputMinimalPoint = Float.parseFloat(fieldMap.get("objectArg").toString());
        long ownerId = DataBaseManager.getOwnerId((String) fieldMap.get("userLogin"), EnterManager.encryptPassword((String) fieldMap.get("userPassword")));

        Connection connection = DataBaseManager.getConnection();
        final String removeCommand = "DELETE FROM \"LabWork\" Where minimalpoint < ? AND owner = ?";
        final String count = "SELECT count(*) FROM \"LabWork\" WHERE minimalpoint< ? AND owner = ?";


        PreparedStatement countCommandQuery = connection.prepareStatement(count);
        countCommandQuery.setFloat(1, inputMinimalPoint);
        countCommandQuery.setLong(2, ownerId);
        ResultSet countDeleted = countCommandQuery.executeQuery();

        try {
            PreparedStatement removeCommandQuery = connection.prepareStatement(removeCommand);
            removeCommandQuery.setFloat(1, inputMinimalPoint);
            removeCommandQuery.setLong(2, ownerId);
            removeCommandQuery.executeQuery();
        }catch (SQLException ignored){}
        countDeleted.next();

        MessageForm messageForm = new MessageForm("Remove lower command result: \n", "Элементов удалено :"+countDeleted.getInt("count"));
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
    }
}
