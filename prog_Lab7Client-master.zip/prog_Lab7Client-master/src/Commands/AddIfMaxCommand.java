package Commands;

import ClientNet.UdpClient;
import Data.LabWork;
import Forms.CommandForm;
import ObjectMaker.LabWorkMaker;

/**
 * Реализует команду add if max
 * Добавляет новый объект в коллекцию если значение поля minimalPoint больше чем максимальное в коллекции
 */
public class AddIfMaxCommand extends Command{
    /**
     * Пробегая по коллекции определяет максимальное значение поля minimalPoint и передаёт его в метод addCommandMethod
     */
    public void commandExecutor(String arg) throws Exception {
        System.out.println("Добавление объекта");
        LabWork objectOfLabWork = LabWorkMaker.initializationFieldsOfLabWork();
        CommandForm commandForm = new CommandForm("/Aim", objectOfLabWork);
        UdpClient.sendClientRequest(commandForm);
    }
}

