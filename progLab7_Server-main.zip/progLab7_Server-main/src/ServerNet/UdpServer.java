package ServerNet;



import Managers.ConfigManager;
import Managers.FieldParsingManager;
import Managers.FormManager;
import Managers.ThreadPoolManager;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RecursiveAction;

public class UdpServer {

    static DatagramChannel datagramChannel;
    static InetSocketAddress serverAddress;
    static ByteBuffer buffer;
    static SocketAddress clientAddress;
    public static LinkedHashMap<String, SocketAddress> usersAddress= new LinkedHashMap<>();


    public static void launcher() throws Exception {
        datagramChannel = DatagramChannel.open();
        serverAddress = new InetSocketAddress(ConfigManager.port);
        datagramChannel.bind(serverAddress);
        datagramChannel.configureBlocking(false);
        System.out.println("Server launched");

    }




    public static void getClientRequest() throws Exception {
        buffer = ByteBuffer.allocate(1024 * 1024);
        buffer.clear();

        while (true) {
            try {
                clientAddress = datagramChannel.receive(buffer);
            } catch (IOException e) {

                throw new RuntimeException(e);
            }
            byte[] bytes = buffer.array();
            if (clientAddress != null) {

                ThreadPoolManager.getFixedThreadService().submit(new GetClientRequest(bytes, clientAddress));
            }

        }
    }


    synchronized public static void setUserAddress(Object object, SocketAddress clientAddress) throws IllegalAccessException {
        HashMap hashMap = FieldParsingManager.fieldParsingManager(object);
        String userLogin = hashMap.get("userLogin").toString();
        if (!usersAddress.containsKey(userLogin)){
            usersAddress.put(userLogin, clientAddress);
        }else{
            usersAddress.remove(userLogin);
            usersAddress.put(userLogin, clientAddress);
        }
    }
    public static SocketAddress getClientAddress(String clientLogin) {
        return usersAddress.get(clientLogin);
    }

    public static class GetClientRequest implements Runnable {
        byte[] bytes;
        SocketAddress clientAddress;

        public GetClientRequest(byte[] bytes, SocketAddress clientAddress) {
            this.bytes = bytes;
            this.clientAddress = clientAddress;
        }

        @Override
        public void run() {

            try (ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes)) {
                try (ObjectInputStream objectInputStream= new ObjectInputStream(byteArrayInputStream)) {
                    Object deserializedData = objectInputStream.readObject();

                    HashMap hashMap = FieldParsingManager.fieldParsingManager(deserializedData);
                    setUserAddress(deserializedData, clientAddress);
                    System.out.println("Server got request " + hashMap + " || Request from: " + getLogin(deserializedData));
                    System.out.println("--------------------------------------------------GET CLIENT REQUEST: " + Thread.currentThread().getName());
                    ThreadPoolManager.getCachedThreadService().execute(new FormManager(deserializedData));
                    buffer.clear();

                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    }


    public static class SendServerRequest extends RecursiveAction {
        private Object object;
        private String userLogin;

        public SendServerRequest(Object object, String userLogin) {
            this.object = object;
            this.userLogin = userLogin;
        }

        @Override
        public void compute() {
            System.out.println("-------------------------------------------------- SEND SERVER REQUEST"+Thread.currentThread().getName());
            System.out.println("Send to user: "+ userLogin);

            try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                 ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream)){

                objectOutputStream.flush();
                objectOutputStream.writeObject(object);
                buffer = ByteBuffer.wrap(byteArrayOutputStream.toByteArray());
                SocketAddress currentClientAddress = getClientAddress(userLogin);
                datagramChannel.send(buffer, currentClientAddress);

                System.out.println("Server sent: " + object + "to address: "+ currentClientAddress+" to user: "+userLogin);
                System.out.println("==========================================================================================\n" +
                                   "                                                                                          \n" +
                        "==========================================================================================\n\n");

                getClientRequest();

            }catch (Exception e){
                e.printStackTrace();
            }
            Thread.currentThread().interrupt();
        }
    }

    public static String getLogin(Object object) throws IllegalAccessException {
        HashMap hashMap = FieldParsingManager.fieldParsingManager(object);
        return hashMap.get("userLogin").toString();
    }
}
