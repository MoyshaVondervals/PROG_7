package ObjectMaker;

import Data.Difficulty;
import Data.LabWork;
import Validators.LabWorkValidator;

import java.time.ZonedDateTime;
import java.util.Arrays;

/**
 * Создание объекта класса LabWork
 */
public class LabWorkMaker {
    public static LabWork initializationFieldsOfLabWork() {

        long id = 0;


        System.out.println("Введите название работы");
        String name = LabWorkValidator.nameValidator();


        System.out.println("Введите минимальное значение (>0)");
        float minimalPoint = LabWorkValidator.minimalPointValidator();


        System.out.println("Введите сложность работы или пропустите значение\n" +
                "Доступны: " + Arrays.toString(Difficulty.values()));
        Difficulty difficulty = LabWorkValidator.difficultyValidator();


        ZonedDateTime creationDate = ZonedDateTime.now();


        LabWork labWork = new LabWork(id, name, CoordinatesMaker.initializationFieldsOfCoordinates(), creationDate, minimalPoint, difficulty, PersonMaker.personMaker());
        return labWork;
    }
}
