package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;

/**
 * Завершает работу программы
 */
public class ExitCommand extends Command {
    private static boolean exFlag = false;
    /**
     * Завершает работу программы
     */
    public void commandExecutor(String arg) {
        exFlag = true;
        CommandForm saveCommandForm = new CommandForm("Save");
        try {
            UdpClient.sendClientRequest(saveCommandForm);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
    public static void exit(){
        System.exit(0);
    }

    public static boolean getExFlag() {
        return exFlag;
    }
}
