package Managers;


import org.checkerframework.checker.units.qual.C;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DataBaseManager {
    static Connection connection;
    private static final String URL = ConfigManager.dataBaseURL;
    public static void ConnectToDatabase(){
        try {
            connection = DriverManager.getConnection(URL, ConfigManager.user, ConfigManager.passWord);
        }catch (Exception e){
            System.out.println("error connecting to database");

        }
    }
    public static Connection getConnection(){
        return connection;
    }
    public static Long getOwnerId(String userLogin, String password) throws Exception {
        String sql = "SELECT userid FROM users WHERE userLogin = ? AND userpassword = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, userLogin);
        preparedStatement.setString(2, password);

        ResultSet resultSet = preparedStatement.executeQuery();
        resultSet.next();
        return resultSet.getLong("userid");
    }
}
