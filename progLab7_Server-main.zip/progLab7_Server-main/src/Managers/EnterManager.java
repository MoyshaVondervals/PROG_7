package Managers;

import Forms.ErrorForm;
import Forms.MessageForm;
import ServerNet.UdpServer;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.HashMap;

import static Managers.FieldParsingManager.fieldParsingManager;

public class EnterManager {

    public static void enterManager(Object object) throws Exception {
        HashMap fieldMap = fieldParsingManager(object);

        String hashPasswd = encryptPassword(fieldMap.get("userPassword").toString());

        if (fieldMap.get("typeOfRequest").equals("REG")){
            registerManager(fieldMap.get("userLogin").toString(), hashPasswd);
        }else if (fieldMap.get("typeOfRequest").equals("LOGIN")){
            loginManager(fieldMap.get("userLogin").toString(), hashPasswd);
        }
    }

    public static void registerManager(String userLogin, String userpasswd) throws Exception {

        Connection connection = DataBaseManager.getConnection();
        PreparedStatement addStatement = connection.prepareStatement("INSERT INTO users (userlogin,userpassword)VALUES (?, ?)");
        PreparedStatement checkUser = connection.prepareStatement("SELECT count(*) FROM users WHERE userlogin = ?");
        checkUser.setString(1,userLogin);
        ResultSet resultSet = checkUser.executeQuery();
        resultSet.next();
        if (resultSet.getInt("count")==0)  {
            addStatement.setString(1, userLogin);
            addStatement.setString(2, userpasswd);
            addStatement.executeUpdate();
            long ownerId = DataBaseManager.getOwnerId( userLogin, userpasswd);
            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(new MessageForm("Access is ALLOWED to user:",userLogin+". Your id in system: "+ownerId), userLogin));
            addStatement.close();

        }
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(new ErrorForm("1","User already exists"), userLogin));
    }

    public static void loginManager(String userLogin, String userpasswd) throws Exception {

        java.sql.Connection connection = DataBaseManager.getConnection();
        PreparedStatement checkUser = connection.prepareStatement("SELECT count(*) FROM users WHERE (userlogin = ?) AND (userpassword = ?)");
        checkUser.setString(1,userLogin);
        checkUser.setString(2,userpasswd);
        ResultSet resultSet = checkUser.executeQuery();
        resultSet.next();
        if (resultSet.getInt("count")==0)  {
            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(new ErrorForm("2","Access DENIED. Check your login and password"), userLogin));
        }else if (resultSet.getInt("count")==1){
            long ownerId = DataBaseManager.getOwnerId( userLogin, userpasswd);
            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(new MessageForm("Access is ALLOWED to user:",userLogin+". Your id in system: "+ownerId), userLogin));
        }
    }

    public static String encryptPassword(String password) throws NoSuchAlgorithmException {

            MessageDigest messageDigest = MessageDigest.getInstance("SHA-224");
            byte[] messageDigestBytes = messageDigest.digest(password.getBytes());
            BigInteger no = new BigInteger(1, messageDigestBytes);
            String hashPasswd = no.toString(16);
            while (hashPasswd.length() < 32) {
                hashPasswd = "0" + hashPasswd;
                
            }
        return hashPasswd;
    }

}
