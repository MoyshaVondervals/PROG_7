package Managers;

import Commands.*;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Выбор комманд
 */
public class CommandManager {
    private static HashMap<String, Command > commandMap = new HashMap<>();
    public static void commandMapFiller(){
        commandMap.put("Help", new HelpCommand());
        commandMap.put("History", new HistoryCommand());
        commandMap.put("Info", new InfoCommand());
        commandMap.put("Show", new ShowCommand());
        commandMap.put("Add", new AddCommand());
        commandMap.put("Update_id", new Update_idCommand());
        commandMap.put("Remove_by_id", new RemoveByIdCommand());
        commandMap.put("/Rbi", new RemoveByIdCommand());
        commandMap.put("Clear", new ClearCommand());
        commandMap.put("Execute", new ExecuteCommand());
        commandMap.put("Exit", new ExitCommand());
        commandMap.put("Add_if_max", new AddIfMaxCommand());
        commandMap.put("/Aim", new AddIfMaxCommand());
        commandMap.put("Remove_lower", new Remove_lowerCommand());
        commandMap.put("Average_of_minimal_point", new AverageOfMinimalPointCommand());
        commandMap.put("/Aomp", new AverageOfMinimalPointCommand());
        commandMap.put("Count_greater_than_minimal_point", new CountGreaterThanMinimalPointCommand());
        commandMap.put("/Cgtmp", new CountGreaterThanMinimalPointCommand());
        commandMap.put("Filter_by_author", new FilterByAuthorCommand());
        commandMap.put("/Fba", new FilterByAuthorCommand());

    }
    private static String s;
    private static Command command;

    public static void commandManager(String ... str){
        if (str.length==0){
            System.out.println("Введите команду. Для того что бы узнать список команд введите Help");
            s = InputManager.inputData();
            command =commandMap.get(s.split(" ")[0]);
        }else{
            s = str[0];
            command = commandMap.get(s.split(" ")[0]);
        }

        try{
            if(command==null){
                System.out.println("No such command");
            }
            else{
                command.commandExecutor(s);
            }
        }catch (Exception e){
            System.out.println("error");
        }
        finally {
            commandManager();
        }
    }
}