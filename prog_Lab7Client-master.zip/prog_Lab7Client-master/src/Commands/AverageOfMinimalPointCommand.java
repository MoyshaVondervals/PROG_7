package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;

/**
 *Поиск среднего значения поля minimalPoint коллекции
 */
public class AverageOfMinimalPointCommand extends Command{
    /**
     * Пробег по коллекции и подсчет среднего значения поля minimalPoint
     */
    public void commandExecutor(String arg) throws Exception {
        CommandForm AompFrom = new CommandForm("/Aomp");
        UdpClient.sendClientRequest(AompFrom);
    }
}
