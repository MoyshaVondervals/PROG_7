package Validators;

import Managers.CommandManager;

/**
 * Валидатор аргументов команд
 */
public class ArgumentValidator {
    public static Float validFloat(String stringInput){
        String [] array = stringInput.split(" ");
        if (array.length ==2){
            try{
                return Float.parseFloat(array[1]);
            }catch (Exception e){
                System.out.println("Ошибка! На вход не поступило аргумента или аргумент имеет не допустимое значение.");
                CommandManager.commandManager();
                return null;
            }
        }
        else{
            System.out.println("Ошибка! На вход не поступило аргумента");
            CommandManager.commandManager();
            return null;
        }
    }

    public static Long validLong(String stringInput){
        String [] array = stringInput.split(" ");
        if (array.length ==2){
            try{
                return Long.parseLong(array[1]);
            }catch (NumberFormatException e){
                System.out.println("Ошибка! На вход не поступило аргумента или аргумент имеет не допустимое значение.");
                CommandManager.commandManager();
                return null;
            }
        }
        else{
            System.out.println("Ошибка! На вход не поступило аргумента или аргумент имеет не допустимое значение.");
            CommandManager.commandManager();
            return null;
        }
    }
    public static String validString(String stringInput){
        String [] array = stringInput.split(" ");
        if (array.length ==2){
            return array[1];
        }
        else{
            System.out.println("Ошибка! На вход не поступило аргумента или аргумент имеет не допустимое значение.");
            CommandManager.commandManager();
            return null;
        }
    }
}
