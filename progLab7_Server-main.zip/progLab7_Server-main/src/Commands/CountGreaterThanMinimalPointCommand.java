package Commands;

import Data.LabWork;
import Forms.MessageForm;
import Managers.CollectionManager;
import Managers.FieldParsingManager;
import Managers.ThreadPoolManager;
import ServerNet.UdpServer;
import com.sun.source.tree.Tree;


import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

/**
 * Считает количество элементов коллекции значение поля minimalPoint которых больше заданного
 */
public class CountGreaterThanMinimalPointCommand extends AbstractCommand{

    public void executeCommand(Object inputObject) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(inputObject);
        float inputMinimalPoint = Float.parseFloat(String.valueOf(fieldMap.get("objectArg")));
        Set<LabWork> collection = CollectionManager.getCollection();
        int quantityOfPoints = (int) collection.stream().filter(e -> e.getMinimalPoint() > inputMinimalPoint).count();
        MessageForm messageForm = new MessageForm("Elements greater than "+inputMinimalPoint+": ",String.valueOf(quantityOfPoints));
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
    }
}
