package Commands;

import Data.LabWork;
import Forms.MessageForm;
import Managers.CollectionManager;
//import Managers.IdManager;
import ServerNet.UdpServer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.*;

/**
 * Сохранение коллекции ф файл
 */
public class SaveCommand extends AbstractCommand{
    /**
     * Сериализация в json и запись в файл
     */
    public void executeCommand(Object arg) throws Exception {
//        String logOfOperation = "";
//        String fileName = CollectionManager.getFileName();
//        logOfOperation = logOfOperation+"\n"+"Попытка сохранения коллекции в файл: " + fileName;
//        ObjectMapper objectMapper = new ObjectMapper();
//        objectMapper.registerModule(new JavaTimeModule());
//        objectMapper.writeValue(new File(fileName), CollectionManager.getCollection());
//        for (Object i: CollectionManager.getCollection()){
//            logOfOperation = logOfOperation+"\n"+ i;
//        }
//        MessageForm messageForm = new MessageForm("Save command result: ", logOfOperation);
//        UdpServer.sendServerRequest(messageForm);



    }
}
