package Commands;

import Data.LabWork;
import Forms.MessageForm;
import Managers.*;
import ServerNet.UdpServer;

import java.time.ZonedDateTime;
import java.util.*;

/**
 * Реализует команду add if max
 * Добавляет новый объект в коллекцию если значение поля minimalPoint больше чем максимальное в коллекции
 */
public class AddIfMaxCommand extends AbstractCommand{
    /**
     * Пробегая по коллекции определяет максимальное значение поля minimalPoint и передаёт его в метод addCommandMethod
     */
    public void executeCommand(Object inputObject) throws Exception {

        HashMap fieldMap = FieldParsingManager.fieldParsingManager(inputObject);
        LabWork objectOfLabWork = (LabWork) fieldMap.get("objectArg");
        float inputMinimalPoint = objectOfLabWork.getMinimalPoint();
        long ownerId = DataBaseManager.getOwnerId((String) fieldMap.get("userLogin"), EnterManager.encryptPassword((String) fieldMap.get("userPassword")));
        if (getMaxMinimalPoint() < inputMinimalPoint){
            AddCommand.addObjToDb(objectOfLabWork, ownerId);
        }
        else {
            MessageForm messageForm = new MessageForm("Add if max command result: ","Переданный объект не записан(по условию команды)");

            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
        }

    }
    public static float getMaxMinimalPoint(){
        float maximumMinimalPoint =-1;
        for (LabWork i: CollectionManager.getCollection()){
            if (i.getMinimalPoint()>maximumMinimalPoint){
                maximumMinimalPoint = i.getMinimalPoint();
            }
        }
        return maximumMinimalPoint;
    }

}

