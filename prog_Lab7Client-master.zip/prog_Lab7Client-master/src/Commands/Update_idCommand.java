package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;
import Managers.CommandManager;
import Validators.ArgumentValidator;

/**
 * Записать новый элемент в коллекцию вместо элемента с указанным id
 */
public class Update_idCommand extends Command{

    public void commandExecutor(String inputCommand) throws Exception {
        Long inputId = ArgumentValidator.validLong(inputCommand);
        CommandForm updateIdForm = new CommandForm("Update_id",inputId);
        UdpClient.sendClientRequest(updateIdForm);
    }


}
