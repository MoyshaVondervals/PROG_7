package Managers;
import ClientNet.UdpClient;
import Forms.EnterForm;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class EnterManager {
    static ArrayList<String>  registerKeys= new ArrayList<String>();
    static ArrayList<String>  loginKeys= new ArrayList<String>();
    private static String userLogin ;
    private static String userPassword ;

    public static void initKeyWords(){
        loginKeys.add("Login");
        loginKeys.add("Log");
        loginKeys.add("L");
        loginKeys.add("1");
        registerKeys.add("Register");
        registerKeys.add("Reg");
        registerKeys.add("R");
        registerKeys.add("0");
    }
    public static void startAutorization() throws Exception {
        initKeyWords();
        typeOfAutorization();
    }


    public static void typeOfAutorization() throws Exception {
        userLogin = "";
        userPassword = "";
        System.out.println("Выберите тип авторизации\n" +
                "Для входа в существующую запись используйте команды: "+loginKeys.toString()+"\n" +
                "Для регистрации используйте команды: "+registerKeys.toString());
        String chooseOfAutorization = InputManager.inputData();
        if (registerKeys.contains(chooseOfAutorization)){
            System.out.println("Create new account");
            registerUser();
        } else if (loginKeys.contains(chooseOfAutorization)) {
            System.out.println("Enter to exist account");
            loginUser();
        }else {
            System.out.println("Create new account");
            registerUser();
        }
    }


    public static void getUserData() throws NoSuchAlgorithmException {
        while (userLogin.isEmpty() | userLogin.length()>32) {
            System.out.println("Введите логин пользователя");
            userLogin = InputManager.inputData();
        }
        while (userPassword.isEmpty()) {
            System.out.println("Введите пароль");
            userPassword = InputManager.inputData();
        }
    }
    public static void registerUser() throws Exception {

        getUserData();
        EnterForm enterForm = new EnterForm(userLogin, userPassword, "REG");
        System.out.printf(userLogin+" "+userPassword);
        UdpClient.sendClientRequest(enterForm);
    }

    public static void loginUser() throws Exception {
        getUserData();
        EnterForm enterForm = new EnterForm(userLogin, userPassword, "LOGIN");
        System.out.println(userLogin+" "+userPassword);
        UdpClient.sendClientRequest(enterForm);
    }

    public static String getUserLogin() {
        return userLogin;
    }

    public static String getUserPassword() {
        return userPassword;
    }
}
