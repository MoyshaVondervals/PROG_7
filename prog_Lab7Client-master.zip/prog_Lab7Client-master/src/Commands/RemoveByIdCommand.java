package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;
import Validators.ArgumentValidator;

/**
 * Удаляет элемент коллекции по id
 */
public class RemoveByIdCommand extends Command{
    public void commandExecutor(String inputCommand) throws Exception {
        Long inputId = ArgumentValidator.validLong(inputCommand);
        CommandForm removeByIdCommandForm = new CommandForm("/Rbi", inputId);
        UdpClient.sendClientRequest(removeByIdCommandForm);
    }
}

