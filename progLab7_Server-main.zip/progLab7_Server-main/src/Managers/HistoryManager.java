package Managers;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * класс формирования списка истории команд
 */
public class HistoryManager {
    static ArrayList<String> arrayOfCommands = new ArrayList<>();


    public static void addToManager(Object inputObject) throws IllegalAccessException {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(inputObject);
        String inputCommand = String.valueOf(fieldMap.get("commandName"));
        arrayOfCommands.add(0,inputCommand);
        if (arrayOfCommands.size()>7){
            arrayOfCommands.remove(arrayOfCommands.size()-1);
        }

    }

    /**
     * @return Получить список истории
     */
    public static ArrayList getHistory(){
        return arrayOfCommands;
    }

}
