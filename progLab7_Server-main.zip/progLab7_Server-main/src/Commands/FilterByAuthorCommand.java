package Commands;

import Forms.MessageForm;
import Managers.CollectionManager;
import Managers.FieldParsingManager;
import Managers.ThreadPoolManager;
import ServerNet.UdpServer;


import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;

/**
 * Класс выполняющий поиск элементов коллекции значение поля person которых совпадает в заданным
 */
public class FilterByAuthorCommand extends AbstractCommand{
    /**
     *Класс выполняющий поиск элементов коллекции значение поля person которых совпадает в заданным
     * Пробег по элементам коллекции и сравнение с заданым person
     */
    public void executeCommand(Object inputObject) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(inputObject);
        Object personForFilter = fieldMap.get("objectArg");

        String logOfFba="";
        for (Object i : CollectionManager.getCollection()) {
                if (i.toString().contains(personForFilter.toString())) {
                    logOfFba = logOfFba+"\n"+i;
                }
        }
        if (logOfFba.length()>0){
            MessageForm messageForm = new MessageForm("Filter by author result: ",logOfFba);
            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
        }else{
            MessageForm messageForm = new MessageForm("Filter by author result: ","Нет элементов удовлетворяющих поиску");
            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
        }

    }
}