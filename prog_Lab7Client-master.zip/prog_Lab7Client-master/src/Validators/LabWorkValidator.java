package Validators;

import Managers.CommandManager;
import Managers.InputManager;
import Data.Difficulty;

import java.util.Random;

/**
 * Валидность полей класса LabWork
 */
public class LabWorkValidator {
    /**
     * @return проверка формата nameValidator на валидность
     */
    public static String nameValidator() {
        boolean flag = false;
        while(!flag){
            String nameInput = InputManager.inputData();
            if (nameInput == null || nameInput.equals("")) {
                System.out.println("Ошибка! Введенное значение не соответствует требованиям.");
            } else {
                flag = true;
                return nameInput;
            }
        }return null;


    }

    public static float minimalPointValidator() {
        boolean flag = false;
        while (!flag) {
            String minimalPointInput = InputManager.inputData();
            try {
                float minimalPoint = Float.parseFloat(minimalPointInput);
                if (minimalPoint > 0) {
                    flag = true;
                    return minimalPoint;
                }
            } catch (NumberFormatException e) {
                System.out.println("Ошибка! Введенное значение не соответствует требованиям.");
            }
        }return 0;
    }


    /**
     * @return проверка формата difficultyValidator на валидность
     */
    public static Difficulty difficultyValidator() {
        boolean flag = false;
        while(!flag){
            String difficultyInput = InputManager.inputData();
            try{
                return Difficulty.valueOf(difficultyInput);
            }catch (NullPointerException | IllegalArgumentException e){
                System.out.println("Ошибка! Введенное значение не соответствует требованиям.");
            }
        }return null;
    }

}
