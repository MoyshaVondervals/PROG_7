package ObjectMaker;


import Data.Person;
import Validators.PersonValidator;

import java.time.LocalDateTime;

/**
 * Создание объекта класса Person
 */
public class PersonMaker {

    /**
     * @return Создание объекта класса Person, значение каждого поля проверяется на валидность
     */
    public static Person personMaker(){

//      Присвоение значения полю personName
        System.out.println("Введите имя исполнителя работы (не может быть пустым или null)");
        String personName = PersonValidator.nameValidator();

//      Присвоение значения полю personBirthday
        System.out.println("Введите дату рождения исполнителя работы в формате yyyy-MM-dd HH:mm");
        LocalDateTime personBirthday = PersonValidator.birthdayValidator();

//      Присвоение значения полю personHeight
        System.out.println("Рост исполнителя работы (>0)");
        double personHeight = PersonValidator.heightValidator();

        return new Person(personName,personBirthday,personHeight);

    }
}
