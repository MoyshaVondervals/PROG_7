package Commands;

import Forms.CommandForm;
import Forms.MessageForm;
import Managers.*;

import ServerNet.UdpServer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;


/**
 * Записать новый элемент в коллекцию вместо элемента с указанным id
 */
public class Update_idCommand extends AbstractCommand{

    public void executeCommand(Object inputObject) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(inputObject);
        Long id = Long.parseLong(String.valueOf(fieldMap.get("objectArg")));
        long ownerId = DataBaseManager.getOwnerId((String) fieldMap.get("userLogin"), EnterManager.encryptPassword((String) fieldMap.get("userPassword")));



        Connection connection = DataBaseManager.getConnection();
        final String removeCommand = "DELETE FROM \"LabWork\" Where labworkid = ? AND owner = ?";
        final String count = "SELECT count(*) FROM \"LabWork\" WHERE labworkid = ? AND owner = ?";

        PreparedStatement countCommandQuery = connection.prepareStatement(count);
        countCommandQuery.setLong(1, id);
        countCommandQuery.setLong(2, ownerId);
        ResultSet countDeleted = countCommandQuery.executeQuery();
        countDeleted.next();

        if (countDeleted.getInt(1) != 0) {
            try {
                PreparedStatement removeCommandQuery = connection.prepareStatement(removeCommand);
                removeCommandQuery.setLong(1, id);
                removeCommandQuery.setLong(2, ownerId);
                removeCommandQuery.executeQuery();
            }catch (SQLException ignored){}
            countDeleted.next();

            CommandForm passedIdForUpdating = new CommandForm("Add");
            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(passedIdForUpdating, String.valueOf(fieldMap.get("userLogin"))));
        }else{
            MessageForm messageForm = new MessageForm("Update id message: ","Нет элемента с таким Id");
            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
        }

//        try {
//            PreparedStatement removeCommandQuery = connection.prepareStatement(updateCommand);
//            removeCommandQuery.setLong(1, id);
//            removeCommandQuery.setLong(2, ownerId);
//            removeCommandQuery.executeQuery();
//        }catch (SQLException igrored){}



//        TreeSet<LabWork> collection = CollectionManager.getCollection();
//        if (IdManager.checkUniquenessOfId(id)){
//            collection.removeIf(e->e.getId()==id);
//            CommandForm passedIdForUpdating = new CommandForm("Add");
//            UdpServer.sendServerRequest(passedIdForUpdating);
//        }else{
//            MessageForm messageForm = new MessageForm("Update id message: ","Нет элемента с таким Id");
//            UdpServer.sendServerRequest(messageForm);
//        }
//
    }


}
