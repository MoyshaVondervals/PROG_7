package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;

/**
 * Вывод общей информации о работе программы
 */
public class InfoCommand extends Command{
    /**
     * Вывод
     * типа коллекции
     * Время создания коллекции
     * Количество элементов коллекции
     * Режим ввода
     */
    public void commandExecutor(String arg) {
        CommandForm infoCommandForm = new CommandForm("Info");
        try {
            UdpClient.sendClientRequest(infoCommandForm);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
