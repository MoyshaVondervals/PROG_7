package Commands;

import Forms.MessageForm;
import Managers.FieldParsingManager;
import Managers.ThreadPoolManager;
import ServerNet.UdpServer;

import java.io.Serializable;
import java.util.HashMap;

/**
 * Вывод сообщения помощника
 */
public class HelpCommand extends AbstractCommand {
    private static final long serialVersionUID = 1L;
    /**
     * Вывод сообщения помощника
     */
    public void executeCommand(Object arg) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(arg);
        MessageForm messageForm = new MessageForm("Help command result: ",
                """
                        ++help : вывести справку по доступным командам
                        ++info : вывести в стандартный поток вывода информацию о коллекции (тип, дата инициализации, количество элементов и т.д.)
                        ++show : вывести в стандартный поток вывода все элементы коллекции в строковом представлении
                        ++add {element} : добавить новый элемент в коллекцию
                        update id {element} : обновить значение элемента коллекции, id которого равен заданному
                        ++remove_by_id id : удалить элемент из коллекции по его id
                        ++clear : очистить коллекцию
                        ++save : сохранить коллекцию в файл
                        execute_script file_name : считать и исполнить скрипт из указанного файла. В скрипте содержатся команды в таком же виде, в котором их вводит пользователь в интерактивном режиме.
                        ++exit : завершить программу (без сохранения в файл)
                        ++add_if_max {element} : добавить новый элемент в коллекцию, если его значение превышает значение наибольшего элемента в этой коллекции
                        ++remove_lower {element} : удалить из коллекции все элементы, меньшие, чем заданный
                        history : вывести последние 7 команд (без их аргументов)
                        ++average_of_minimal_point : вывести среднее значение поля minimalPoint для всех элементов коллекции
                        ++count_greater_than_minimal_point minimalPoint : вывести количество элементов значение поля minimalPoint которых больше заданного
                        ++filter_by_author author : вывести элементы, значение поля author которых равно заданному
                """);
        System.out.println("Help command for user: "+ fieldMap.get("userLogin"));
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
    }
}
