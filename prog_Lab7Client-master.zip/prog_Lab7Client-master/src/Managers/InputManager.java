package Managers;

import Commands.ExecuteCommand;

import java.util.Scanner;

/**
 * Контроль входных значений
 */
public class InputManager {

    /**
     * @return Выбор типа ввода и ввод согласно типу
     */
    public static String inputData() {

        if (ExecuteCommand.getScriptCollection().isEmpty()) {
            Scanner scanner = new Scanner(System.in);
            return scanner.nextLine();
        } else  {
            String currentCommand = ExecuteCommand.getCommandOfScript();
            System.out.println(currentCommand);
            return currentCommand;
        }
    }
}
