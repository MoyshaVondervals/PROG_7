package Commands;

import ClientNet.UdpClient;
import Data.LabWork;
import Forms.CommandForm;
import ObjectMaker.LabWorkMaker;

/**
 * Класс реализующий добавление объекта класса LabWork в коллекцию
 */
public class AddCommand extends Command {
    public void commandExecutor(String arg) throws Exception {

            System.out.println("Добавление объекта");
            LabWork objectOfLabWork = LabWorkMaker.initializationFieldsOfLabWork();
            CommandForm addCommandForm = new CommandForm("Add", objectOfLabWork);
            UdpClient.sendClientRequest(addCommandForm);


    }
}