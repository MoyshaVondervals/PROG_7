package Data;

import java.io.Serializable;

/**
 * Доступные варианты сложности
 */
public enum Difficulty implements Serializable {
    EASY,
    NORMAL,
    HARD,
    VERY_HARD;
}