package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;

/**
 * Очищает коллекцию
 */
public class ClearCommand extends Command{
    /**
     * Очищает коллекцию и обновляет значения в коллекции id
     */
    public void commandExecutor(String arg){
        CommandForm clearCommandForm = new CommandForm("Clear");
        try {
            UdpClient.sendClientRequest(clearCommandForm);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
