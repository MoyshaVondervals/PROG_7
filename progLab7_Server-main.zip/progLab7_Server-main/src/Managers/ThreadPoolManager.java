package Managers;

import java.util.concurrent.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ThreadPoolManager {
    static ExecutorService fixedThreadService = Executors.newFixedThreadPool(50);
    static ExecutorService cachedThreadService = Executors.newCachedThreadPool();
    static ForkJoinPool forkJoinPool = new ForkJoinPool(50);




    public static ExecutorService getFixedThreadService() {
        return fixedThreadService;
    }

    public static ExecutorService getCachedThreadService() {
        return cachedThreadService;
    }

    public static ForkJoinPool getForkJoinPool() {
        return forkJoinPool;
    }
}
