package Commands;

/**
 * Интерфейс для вызова комманд
 */
public interface Executable {
    void commandExecutor(String arg) throws Exception;
}

