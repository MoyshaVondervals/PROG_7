package Data;

import java.io.Serial;
import java.io.Serializable;

/**
 * Класс координат
 */
public class Coordinates implements Serializable {
    @Serial
    private static final long serialVersionUID = 12L;
    private float x; //Поле не может быть null
    private float y;

    public Coordinates(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public void setX(Long x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    @Override
    public String toString() {
        return "Coordinates{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}
