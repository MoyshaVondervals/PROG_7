package ObjectMaker;

import Data.Coordinates;
import Validators.CoordinatesValidator;

/**
 * Создание объекта класса Coordinates
 */
public class CoordinatesMaker {
    static public Coordinates initializationFieldsOfCoordinates(){
        System.out.println("Введите координату по Х (max:462)");
        float Xaxis = CoordinatesValidator.XaxisValidator();


        System.out.println("Введите координату по Y");
        float Yaxis = CoordinatesValidator.YaxisValidator();
        return new Coordinates(Xaxis,Yaxis);


    }
}
