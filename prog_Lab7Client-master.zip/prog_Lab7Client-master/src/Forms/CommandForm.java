package Forms;

import Managers.EnterManager;

import java.io.Serializable;
import java.util.Arrays;

public class CommandForm implements Serializable {
    private static final long serialVersionUID = 100L;
    private String commandName;
    private String arg;
    private Object objectArg;
    private final String userLogin  = EnterManager.getUserLogin();
    private final String userPassword = EnterManager.getUserPassword();


    public CommandForm(String commandName) {
        this.commandName = commandName;

    }
    public CommandForm(String commandName, Object  arg) {
        this.commandName = commandName;
        this.objectArg = arg;
    }



    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }

    public void setArg(String arg) {
        this.arg = arg;
    }

    @Override
    public String toString() {
        return "CommandForm;" + commandName + ';' + arg;
    }
}
