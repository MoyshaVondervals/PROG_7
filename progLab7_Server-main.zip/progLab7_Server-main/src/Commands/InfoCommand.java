package Commands;

import Forms.MessageForm;
import Managers.CollectionManager;
import Managers.FieldParsingManager;
import Managers.ThreadPoolManager;
import ServerNet.UdpServer;

import java.util.HashMap;

/**
 * Вывод общей информации о работе программы
 */
public class InfoCommand extends AbstractCommand{
    /**
     * Вывод
     * типа коллекции
     * Время создания коллекции
     * Количество элементов коллекции
     * Режим ввода
     */
    public void executeCommand(Object arg) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(arg);
        MessageForm messageForm = new MessageForm("Info command result: \n","Тип коллекции: TreeSet\n" +
                "Дата и время создания данной коллекции: "+ CollectionManager.getTime()+"\n" +
                "Количество элементов коллекции: "+ CollectionManager.getCollection().size());
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
    }
}
