package Managers;

import Commands.AbstractCommand;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;

public class FieldParsingManager {
    private static final HashMap<String, Object> fieldsMap = new HashMap<>();
    public static HashMap fieldParsingManager(Object inputObject) throws IllegalAccessException {

        Class<? extends Object> clazz = inputObject.getClass();
        Field[] fields = clazz.getDeclaredFields();
        for(Field field: fields){
            String fieldName = field.getName();
            if(!field.isAccessible()){
                field.setAccessible(true);
            }

            Object value = field.get(inputObject);
            fieldsMap.put(fieldName, value);
        }
        return fieldsMap;
    }
}
