
import Managers.*;
import ServerNet.UdpServer;

import java.sql.SQLOutput;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static ServerNet.UdpServer.getClientRequest;


public class ServerMain {

    public static void main(String[] args) throws Exception {
        ConfigManager.getConfig();
        CommandManager.commandMapFiller();
        UdpServer.launcher();
        DataBaseManager.ConnectToDatabase();
        CollectionManager.baseParser();
        System.out.println("Server started");
//        while (true) {

            getClientRequest();
//        }




    }
}