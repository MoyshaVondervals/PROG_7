package Forms;

import java.io.Serializable;

public class EnterForm implements Serializable {
    private static final long serialVersionUID = 102L;
    private String userLogin;
    private String userPassword;
    private String typeOfRequest;

    public EnterForm(String userLogin, String userPassword, String typeOfRequest) {
        this.userLogin = userLogin;
        this.userPassword = userPassword;
        this.typeOfRequest = typeOfRequest;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getTypeOfRequest() {
        return typeOfRequest;
    }

    public void setTypeOfRequest(String typeOfRequest) {
        this.typeOfRequest = typeOfRequest;
    }
}
