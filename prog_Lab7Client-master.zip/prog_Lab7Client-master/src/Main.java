
import ClientNet.UdpClient;

import Managers.CommandManager;
import Managers.EnterManager;


public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Лабораторная работа №6");
        UdpClient.launcher();

        CommandManager.commandMapFiller();
        EnterManager.startAutorization();
        CommandManager.commandManager();
        }
    }