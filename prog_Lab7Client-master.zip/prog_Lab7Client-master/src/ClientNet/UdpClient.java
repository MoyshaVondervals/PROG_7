package ClientNet;

import Commands.ExitCommand;
import Managers.CommandManager;
import Managers.FieldParsingManager;
import Managers.ServerErrorManager;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.sql.SQLOutput;
import java.util.HashMap;

public class UdpClient {
    static int port = 1488;
    static ByteBuffer buffer = null;
    static DatagramChannel datagramChannel;
    static InetSocketAddress serverAddress;

    public static void launcher() throws IOException {
        datagramChannel = DatagramChannel.open();
        datagramChannel.configureBlocking(false);
        serverAddress = new InetSocketAddress("localhost",port);
        System.out.println("Client launched");
    }

    public static void sendClientRequest(Object object) throws Exception {
        if (!datagramChannel.isConnected()){
            System.out.println("Ошибка подключения");
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
        objectOutputStream.flush();
        objectOutputStream.writeObject(object);
        buffer = ByteBuffer.wrap(byteArrayOutputStream.toByteArray());
        datagramChannel.send(buffer,serverAddress);
        System.out.println("Client sent: "+object.toString()+" "+ (buffer.array().length));
        buffer.clear();
        getServerRequest();

    }
    public static void getServerRequest() throws Exception {
        buffer = ByteBuffer.allocate(1024 * 1024);
        byte[] array = buffer.array();
            datagramChannel.receive(buffer);
        if (buffer.array()[0]==0) {
            Thread.sleep(100);
            getServerRequest();
        }
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(buffer.array());
        ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
        Object deserializedData = objectInputStream.readObject();
        if (ExitCommand.getExFlag()){
            ExitCommand.exit();
        }
        if (deserializedData.getClass().getName().equals("Forms.MessageForm")) {
            System.out.println("Client received: " + deserializedData);
        } else if (deserializedData.getClass().getName().equals("Forms.CommandForm")) {
            HashMap fieldMap = FieldParsingManager.fieldParsingManager(deserializedData);
            String commandName = fieldMap.get("commandName").toString();
            CommandManager.commandManager(commandName);
        } else if ("Forms.ErrorForm".equals(deserializedData.getClass().getName())) {
            HashMap fieldMap = FieldParsingManager.fieldParsingManager(deserializedData);
            ServerErrorManager.serverErrorManager(fieldMap.get("errorCode").toString());
        }

        CommandManager.commandManager();
        buffer.clear();
    }
}
