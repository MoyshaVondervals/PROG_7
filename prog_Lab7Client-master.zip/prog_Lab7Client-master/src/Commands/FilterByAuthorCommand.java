package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;
import ObjectMaker.PersonMaker;

/**
 * Класс выполняющий поиск элементов коллекции значение поля person которых совпадает в заданным
 */
public class FilterByAuthorCommand extends Command{
    /**
     *Класс выполняющий поиск элементов коллекции значение поля person которых совпадает в заданным
     * Пробег по элементам коллекции и сравнение с заданым person
     */
    public void commandExecutor(String arg) throws Exception {
        String PersonObject = PersonMaker.personMaker().toString();
        CommandForm filterByAuthorCommandForm = new CommandForm("/Fba",PersonObject);
        UdpClient.sendClientRequest(filterByAuthorCommandForm);
    }
}