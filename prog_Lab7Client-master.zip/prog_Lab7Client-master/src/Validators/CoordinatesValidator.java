package Validators;

import Managers.CommandManager;
import Managers.InputManager;

/**
 * Валидность полей класса Coordinates
 */
public class CoordinatesValidator {
    /**
     * @return проверка формата XaxisValidator на валидность
     */
    public static float XaxisValidator(){
        boolean flag = false;
        float Xaxis = 0;
        while (!flag){
            String XaxisInput = InputManager.inputData();
            try{
            assert XaxisInput != null;
            Xaxis = Float.parseFloat(XaxisInput);
            if (Xaxis < 462){
                flag = true;
                return Xaxis;
            }else{
                System.out.println("Ошибка! Введенное значение не соответствует требованиям. Попробуйте снова.");

            }

        }catch (NumberFormatException e){
            System.out.println("Ошибка Введенное значение не соответствует требованиям. Попробуйте снова.");
        }
        }
        return Xaxis;
    }
    /**
     * @return проверка формата YaxisValidator на валидность
     */
    public static float YaxisValidator(){
        boolean flag = false;
        while (!flag){
            String YaxisInput = InputManager.inputData();
            try{
                float Yaxis = Float.parseFloat(YaxisInput);
                flag= true;
                return Yaxis;
            }catch (NumberFormatException e){
                System.out.println("Ошибка! Введенное значение не соответствует требованиям. Попробуйте снова.");
            }
        }
        return 0;


    }
}
