package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;

/**
 * Вывод истории ввода команд
 */
public class HistoryCommand extends Command {
    /**
     * вывод истории ввода команд
     */
    @Override
    public void commandExecutor(String arg) throws Exception {
        CommandForm historyForm = new CommandForm("History");
        UdpClient.sendClientRequest(historyForm);
    }

}
