package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;

public class ShowCommand extends Command{
    /**
     * Показывает все элементы коллекции
     */
    public void commandExecutor(String arg){
        CommandForm showCommandForm = new CommandForm("Show");
        try {
            UdpClient.sendClientRequest(showCommandForm);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }
}
