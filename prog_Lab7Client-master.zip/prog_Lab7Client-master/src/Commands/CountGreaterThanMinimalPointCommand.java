package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;
import Validators.ArgumentValidator;

/**
 * Считает количество элементов коллекции значение поля minimalPoint которых больше заданного
 */
public class CountGreaterThanMinimalPointCommand extends Command{
    /**
     * @param inputCommand - значение аргумена
     *                     сравнивает значение всех элементов коллекции с переданым аргументом
     */
    public void commandExecutor(String inputCommand) throws Exception {
        Float inputMinimalPoint = ArgumentValidator.validFloat(inputCommand);
        CommandForm CgtmpForm = new CommandForm("/Cgtmp",inputMinimalPoint);
        UdpClient.sendClientRequest(CgtmpForm);
    }
}
