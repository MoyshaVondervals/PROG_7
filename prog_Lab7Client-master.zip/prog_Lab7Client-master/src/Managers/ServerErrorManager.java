package Managers;

public class ServerErrorManager {
    public static void serverErrorManager(String codeError) throws Exception {
        if (codeError.equals("1")){
            EnterManager.typeOfAutorization();
        }else if (codeError.equals("2")){
            EnterManager.typeOfAutorization();
        }
    }
}
