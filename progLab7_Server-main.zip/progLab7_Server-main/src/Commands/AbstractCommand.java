package Commands;

import java.net.SocketAddress;

/**
 * Абстрактный класс описывающий команды
 */
public abstract class AbstractCommand implements ExecutableCommand{
    @Override
    public void executeCommand(Object arg) throws Exception {
    }

}
