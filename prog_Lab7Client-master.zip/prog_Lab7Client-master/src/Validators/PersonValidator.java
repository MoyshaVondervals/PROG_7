package Validators;

import Managers.InputManager;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Валидность полей класса Person
 */
public class PersonValidator {
    /**
     * @return проверка формата nameValidator на валидность
     */
    public static String nameValidator(){
        boolean flag = false;
        while(!flag){
            String nameInput = InputManager.inputData();
            if (nameInput==null||nameInput.equals("")){
                System.out.println("Ошибка! Введенное значение не соответствует требованиям.");
            }else{
                flag = true;
                return nameInput;
            }
        }return null;

    }

    /**
     * @return проверка формата birthdayValidator на валидность
     */
    public static LocalDateTime birthdayValidator(){
        boolean flag = false;
        while(!flag){
            String birthdayInput = InputManager.inputData();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            try {
                LocalDateTime time = LocalDateTime.parse(birthdayInput,formatter);
                flag = true;
                return time;
            }catch (DateTimeParseException e){
                System.out.println("Ошибка! Введенное значение не соответствует требованиям.");

            }
        }return LocalDateTime.MIN;
    }

    /**
     * @return проверка формата heightValidator на валидность
     */
    public static double heightValidator(){
        boolean flag = false;
        while(!flag){
            String heightInput = InputManager.inputData();
            try {
                flag = true;
                return Double.parseDouble(heightInput);
            }catch (NumberFormatException e){
                System.out.println("Ошибка! Введенное значение не соответствует требованиям.");
            }
        }return 0;

    }
}
