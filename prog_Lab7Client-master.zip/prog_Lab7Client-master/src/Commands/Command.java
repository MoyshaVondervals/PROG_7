package Commands;

/**
 * абстрактный класс описывающий команды
 */
public abstract class Command implements Executable{
    @Override
    public void commandExecutor(String arg) throws Exception {
    }

}
