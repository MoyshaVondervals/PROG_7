package Forms;


import java.io.Serializable;

public class MessageForm implements Serializable {
    private static final long serialVersionUID = 101L;
    private String title;
    private String text;

    public MessageForm(String title, String text) {
        this.title = title;
        this.text = text;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "MessageForm " + title + ' ' + text;
    }
}
