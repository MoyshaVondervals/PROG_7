package Commands;

import Forms.MessageForm;
import Managers.FieldParsingManager;
import Managers.HistoryManager;
import Managers.ThreadPoolManager;
import ServerNet.UdpServer;

import java.util.HashMap;


/**
 * Вывод истории ввода команд
 */
public class HistoryCommand extends AbstractCommand {
    /**
     * вывод истории ввода команд
     */
    @Override
    public void executeCommand(Object arg) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(arg);
        MessageForm messageForm = new MessageForm("History of commands: ",HistoryManager.getHistory().toString());
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
    }

}
