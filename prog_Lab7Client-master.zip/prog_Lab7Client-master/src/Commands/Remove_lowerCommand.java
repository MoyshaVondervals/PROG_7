package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;
import Validators.ArgumentValidator;

import java.util.LinkedHashSet;

/**
 * Удаляет все элементы значение поля minimalPoint которых менее заданного в аргументе inputCommand
 */
public class Remove_lowerCommand extends Command{
    static LinkedHashSet<Object> objectLinkedHashSet= new LinkedHashSet<>();

    /**
     * @param inputCommand - аргумент со значением которого идёт сравнение.
     *                      Добавляет в буферную коллекцию все элементы значение поля minimalPoint
     *                      которых менее заданного в аргументе inputCommand
     */
    public void commandExecutor(String inputCommand) throws Exception {
        Long inputMinimalPoint = ArgumentValidator.validLong(inputCommand);
        CommandForm removeByIdCommandForm = new CommandForm("Remove_lower", inputMinimalPoint);
        UdpClient.sendClientRequest(removeByIdCommandForm);
    }
}
