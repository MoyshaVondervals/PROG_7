package Commands;

import Data.LabWork;
import Forms.MessageForm;
import Managers.*;
import ServerNet.UdpServer;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.TreeSet;
//import Managers.IdManager;
//import Validators.ArgumentValidator;

/**
 * Удаляет элемент коллекции по id
 */
public class RemoveByIdCommand extends AbstractCommand{

    public void executeCommand(Object inputObject) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(inputObject);
        Long id = Long.valueOf(fieldMap.get("objectArg").toString());
        long ownerId = DataBaseManager.getOwnerId((String) fieldMap.get("userLogin"), EnterManager.encryptPassword((String) fieldMap.get("userPassword")));


        Connection connection = DataBaseManager.getConnection();
        final String removeCommand = "DELETE FROM \"LabWork\" Where labworkid = ? AND owner = ?";
        final String count = "SELECT count(*) FROM \"LabWork\" WHERE labworkid = ? AND owner = ?";


        PreparedStatement countCommandQuery = connection.prepareStatement(count);
        countCommandQuery.setLong(1, id);
        countCommandQuery.setLong(2, ownerId);
        ResultSet countDeleted = countCommandQuery.executeQuery();

        try {
            PreparedStatement removeCommandQuery = connection.prepareStatement(removeCommand);
            removeCommandQuery.setLong(1, id);
            removeCommandQuery.setLong(2, ownerId);
            removeCommandQuery.executeQuery();
        }catch (SQLException ignored){}
        countDeleted.next();


        MessageForm messageForm = new MessageForm("Remove lower command result: \n", "Элементов удалено :"+countDeleted.getInt("count"));
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));

    }
}