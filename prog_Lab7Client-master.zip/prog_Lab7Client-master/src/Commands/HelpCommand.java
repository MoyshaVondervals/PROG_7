package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;


import java.io.Serializable;

/**
 * Вывод сообщения помощника
 */
public class HelpCommand extends Command implements Serializable {

    /**
     * Вывод сообщения помощника
     */
    public void commandExecutor(String arg) {
        CommandForm helpCommandForm = new CommandForm("Help");
        try {
            UdpClient.sendClientRequest(helpCommandForm);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
