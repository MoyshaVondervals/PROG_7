package Commands;

/**
 * Интерфейс для вызова комманд
 */
public interface ExecutableCommand {
    void executeCommand(Object arg) throws Exception;
}

