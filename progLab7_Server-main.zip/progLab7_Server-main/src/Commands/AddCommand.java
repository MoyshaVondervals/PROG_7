package Commands;

import Data.LabWork;
import Forms.MessageForm;
import Managers.*;
import ServerNet.UdpServer;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


/**
 * Класс реализующий добавление объекта класса LabWork в коллекцию
 */
public class AddCommand extends AbstractCommand {



    public void executeCommand(Object inputObject) throws Exception {
        System.out.println("ADD THREAD: "+ Thread.currentThread().getName());
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(inputObject);
        LabWork objectOfLabWork = (LabWork) fieldMap.get("objectArg");
        long ownerId = DataBaseManager.getOwnerId((String) fieldMap.get("userLogin"), EnterManager.encryptPassword((String) fieldMap.get("userPassword")));
        try {
            addObjToDb(objectOfLabWork, ownerId);
            CollectionManager.baseParser();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("Error adding object to DB");
        }
        System.out.println("with add"+CollectionManager.getCollection());
        String logOfAddCommand = "Данные добавлены в коллекцию. Объекту присвоен идентификатор" +
                "Сохранение произойдет после перед завершение работы программы. Команда Exit";
        MessageForm messageForm = new MessageForm("Add command result: ", logOfAddCommand);
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
    }

    public static void addObjToDb(LabWork objectOfLabWork, long ownerId) throws SQLException {
        Connection connection = DataBaseManager.getConnection();
        PreparedStatement addObjStatement = connection.prepareStatement("INSERT INTO \"LabWork\" (labworkname, coordinate_x, coordinate_y, creationdate, minimalpoint, difficulty, personname, personbirthday, personheight, owner)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        addObjStatement.setString(1, objectOfLabWork.getName());
        addObjStatement.setFloat(2, objectOfLabWork.getCoordinates().getX());
        addObjStatement.setFloat(3, objectOfLabWork.getCoordinates().getY());
        addObjStatement.setString(4, String.valueOf(objectOfLabWork.getCreationDate()));
        addObjStatement.setFloat(5, objectOfLabWork.getMinimalPoint());
        addObjStatement.setString(6, String.valueOf(objectOfLabWork.getDifficulty()));
        addObjStatement.setString(7, objectOfLabWork.getAuthor().getName());
        addObjStatement.setString(8, String.valueOf(objectOfLabWork.getAuthor().getBirthday()));
        addObjStatement.setDouble(9, objectOfLabWork.getAuthor().getHeight());
        addObjStatement.setLong(10, ownerId);

        addObjStatement.executeUpdate();

    }

}



