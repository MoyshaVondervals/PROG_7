package Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * класс person
 */
public class Person implements Serializable {

    private static final long serialVersionUID = 11L;
    private String name; //Поле не может быть null, Строка не может быть пустой
    private java.time.LocalDateTime birthday; //Поле не может быть null
    private double height; //Значение поля должно быть больше 0

    public Person(String name, LocalDateTime birthday, double height) {
        this.name = name;
        this.birthday = birthday;
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDateTime birthday) {
        this.birthday = birthday;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", birthday=" + birthday +
                ", height=" + height +
                '}';
    }

}
