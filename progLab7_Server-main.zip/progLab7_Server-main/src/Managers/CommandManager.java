package Managers;

import Commands.*;
import Forms.MessageForm;
import ServerNet.UdpServer;

import java.util.HashMap;

/**
 * Выбор комманд
 */
public class CommandManager{
    private static final HashMap<String, AbstractCommand > commandMap = new HashMap<>();
    public static void commandMapFiller(){
        commandMap.put("Help", new HelpCommand());
        commandMap.put("History", new HistoryCommand());
        commandMap.put("Info", new InfoCommand());
        commandMap.put("Show", new ShowCommand());
        commandMap.put("Add", new AddCommand());
        commandMap.put("Update_id", new Update_idCommand());
        commandMap.put("Remove_by_id", new RemoveByIdCommand());
        commandMap.put("/Rbi", new RemoveByIdCommand());
        commandMap.put("Clear", new ClearCommand());
        commandMap.put("Save", new SaveCommand());
        commandMap.put("Add_if_max", new AddIfMaxCommand());
        commandMap.put("/Aim", new AddIfMaxCommand());
        commandMap.put("Remove_lower", new Remove_lowerCommand());
        commandMap.put("Average_of_minimal_point", new AverageOfMinimalPointCommand());
        commandMap.put("/Aomp", new AverageOfMinimalPointCommand());
        commandMap.put("/Cgtmp", new CountGreaterThanMinimalPointCommand());
        commandMap.put("Filter_by_author", new FilterByAuthorCommand());
        commandMap.put("/Fba", new FilterByAuthorCommand());
    }

    public static void commandManager(Object object) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(object);
        String s = object.toString();
        HistoryManager.addToManager(object);
        AbstractCommand command =commandMap.get(object.toString().split(";")[1]);
        try{
            if(command==null){
                System.out.println("No such command");
                ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest( new MessageForm("Нет такой команды!",""), String.valueOf(fieldMap.get("userLogin=12"))));
            }
            else{
                System.out.println("Command executing...");
                command.executeCommand(object);
            }
        }catch (Exception e){
            System.out.println("Command manager error");
            e.printStackTrace();
            ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(new MessageForm("Ошибка",""), String.valueOf(fieldMap.get("userLogin=12"))));

        }

    }
}
