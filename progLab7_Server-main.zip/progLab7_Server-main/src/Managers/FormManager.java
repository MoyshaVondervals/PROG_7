package Managers;


import Forms.MessageForm;
import ServerNet.UdpServer;


public class FormManager implements Runnable{
    private Object object;

    public FormManager(Object object) {
        this.object = object;
    }

    @Override
    public void run() {

        String formType = object.toString().split(";")[0];
        try {
            System.out.println("Form from: "+ UdpServer.getLogin(object));
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        System.out.println("--------------------------------------------------FORM MANAGER" + Thread.currentThread().getName());
        System.out.println(formType);
        try{
            if (formType.equals("CommandForm")) {
                CommandManager.commandManager(object);
            }else if(formType.contains("EnterForm")){
                EnterManager.enterManager(object);
            }
        }catch (Exception e){
            MessageForm messageForm =new MessageForm("Error of Form manager","");
        }

    }
}
