package Managers;

import Data.Coordinates;
import Data.Difficulty;
import Data.LabWork;
import Data.Person;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

/**
 * Контроллер ГЛАВНОЙ коллекции
 */
public class CollectionManager {

    static Set<LabWork> objectTreeSet = Collections.synchronizedSet(new TreeSet<>());
    static LocalDateTime time = LocalDateTime.now();
    private static final String getAllObjects = "SELECT * FROM \"LabWork\"";


    /**
     * @return - текущее время
     */
    public static LocalDateTime getTime(){
        return time;
    }

    /**
     * Парсер файла
     */

    public static void baseParser() throws SQLException {
        Connection connection = DataBaseManager.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(getAllObjects);
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            LabWork labWork = extractor(resultSet);
            objectTreeSet.add(labWork);
        }
    }



    /**
     * @return Получить коллекцию
     */
    public static Set<LabWork> getCollection(){
        return objectTreeSet;
    }

    public static LabWork extractor(ResultSet result) throws SQLException {
        Long id = result.getLong("labworkid");;
        String name = result.getString("labworkname");
        Float x =  result.getFloat("coordinate_x");
        Float y =  result.getFloat("coordinate_y");
        ZonedDateTime creationDate = ZonedDateTime.parse(result.getString("creationdate"));
        Float minimalPoint = result.getFloat("minimalpoint");
        Difficulty difficulty = Difficulty.valueOf(result.getString("difficulty"));
        String personName = result.getString("personname");
        LocalDateTime birthday = LocalDateTime.parse(result.getString("personBirthday"));
        Double height = result.getDouble("personheight");
        Long ownerId = result.getLong("owner");

        Coordinates coordinates = new Coordinates(x, y);
        Person person = new Person(personName, birthday, height);
        LabWork labWork = new LabWork(id, name, coordinates, creationDate, minimalPoint, difficulty, person, ownerId);


        return labWork;
    }
}