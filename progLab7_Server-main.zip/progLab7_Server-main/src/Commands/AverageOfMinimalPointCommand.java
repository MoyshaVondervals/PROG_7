package Commands;

import Data.LabWork;
import Forms.MessageForm;
import Managers.*;
import ServerNet.UdpServer;

import java.util.HashMap;
import java.util.TreeSet;

/**
 *Поиск среднего значения поля minimalPoint коллекции
 */
public class AverageOfMinimalPointCommand extends AbstractCommand{
    /**
     * Пробег по коллекции и подсчет среднего значения поля minimalPoint
     */
    public void executeCommand(Object arg) throws Exception {
        float sumOfPoints = 0;
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(arg);
        long ownerId = DataBaseManager.getOwnerId((String) fieldMap.get("userLogin"), EnterManager.encryptPassword((String) fieldMap.get("userPassword")));
        for (LabWork i : CollectionManager.getCollection()) {
            if (i.getOwnerId() == ownerId) {
                sumOfPoints = sumOfPoints + i.getMinimalPoint();
            }
        }
        float result = sumOfPoints/ CollectionManager.getCollection().size();
        MessageForm messageForm = new MessageForm("Average of minimal point result: ",String.valueOf(result));
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));
    }
}
