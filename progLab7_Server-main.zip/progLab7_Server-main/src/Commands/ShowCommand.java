package Commands;

import Forms.MessageForm;
import Managers.CollectionManager;
import Managers.FieldParsingManager;
import Managers.ThreadPoolManager;
import ServerNet.UdpServer;

import java.util.HashMap;

public class ShowCommand extends AbstractCommand{

    /**
     * Показывает все элементы коллекции
     */
    synchronized public void executeCommand(Object arg) throws Exception {
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(arg);
        StringBuilder resultString = new StringBuilder();
        System.out.println("--------------------------------------------------Show command  "+Thread.currentThread().getName());
        for (Object i: CollectionManager.getCollection()) {
            resultString.append(i.toString());
        }
        MessageForm messageForm = new MessageForm("Show command result: ", resultString.toString());
        System.out.println("Show command for user: "+ fieldMap.get("userLogin"));
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));


    }
}
