package Commands;

import ClientNet.UdpClient;
import Forms.CommandForm;
import Managers.CommandManager;
import Validators.ArgumentValidator;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Исполняет скрипт из файла в автоматическом режиме
 */
public class ExecuteCommand extends Command{
    static ArrayList<String> arrayOfScript = new ArrayList<>();
    public void commandExecutor(String arg) throws Exception {
        executeCommand(arg);
    }



    /**
     * @param inputData - входной аргумент (имя файла без расширения .txt)
     *                  Проверяет валидность аргумента, открывает файл, всё прочитанное
     *                  записывает в коллекцию, представляющую собой последовательность команд
     */
    public static void executeCommand(String inputData) {

        String fileName = ArgumentValidator.validString(inputData) +".txt";
        try {
            FileReader fr = new FileReader(fileName);
            Scanner scanner = new Scanner(fr);
            System.out.println("""
                    -=-=-=-=-=-=-=-=-=-=-=-=-
                    | Автоматический режим. |
                    -=-=-=-=-=-=-=-=-=-=-=-=-""");
            while (scanner.hasNextLine()) {
                String s = scanner.nextLine();
                arrayOfScript.add(s);
            }
            arrayOfScript.add("");
            System.out.println("Команды получены");
            CommandManager.commandManager();
        } catch (Exception e) {
            System.out.println("Error!");

        }

    }


    /**
     * @return возврат каждой команды из коллекции с последующим
     * её удалением из коллекции как выполненой
     */
    public static String getCommandOfScript() {
        if (!arrayOfScript.isEmpty()){
            String ExecutingCommand = arrayOfScript.get(0);
            arrayOfScript.remove(0);
            return ExecutingCommand;

        }else{
            System.out.println("Закончено создание объектов для сериализации");
            CommandManager.commandManager();
        }
        return null;
    }



    /**
     * @return возвращает коллекцию элементов скрипта
     */
    public static ArrayList<String> getScriptCollection() {

        return arrayOfScript;
    }



}