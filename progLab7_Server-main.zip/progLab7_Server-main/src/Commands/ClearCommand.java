package Commands;

import Forms.MessageForm;
import Managers.*;
//import Managers.IdManager;
import ServerNet.UdpServer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * Очищает коллекцию
 */
public class ClearCommand extends AbstractCommand{
    /**
     * Очищает коллекцию и обновляет значения в коллекции id
     */
    public void executeCommand(Object arg) throws Exception {
        CollectionManager.getCollection().clear();
        Connection connection = DataBaseManager.getConnection();
        HashMap fieldMap = FieldParsingManager.fieldParsingManager(arg);

        long ownerId = DataBaseManager.getOwnerId((String) fieldMap.get("userLogin"), EnterManager.encryptPassword((String) fieldMap.get("userPassword")));

        final String removeCommand = "DELETE FROM \"LabWork\" Where owner = ?";
        final String count = "SELECT count(*) FROM \"LabWork\" WHERE owner = ?";

        PreparedStatement countCommandQuery = connection.prepareStatement(count);
        countCommandQuery.setLong(1, ownerId);
        ResultSet countDeleted = countCommandQuery.executeQuery();

        try {
            PreparedStatement removeCommandQuery = connection.prepareStatement(removeCommand);
            removeCommandQuery.setLong(1, ownerId);
            removeCommandQuery.executeQuery();
        }catch (SQLException ignored){}


        countDeleted.next();
        MessageForm messageForm = new MessageForm("Help command result: ", "Коллекция очищена, удалено: "+ countDeleted.getInt("count"));
        ThreadPoolManager.getForkJoinPool().invoke(new UdpServer.SendServerRequest(messageForm, String.valueOf(fieldMap.get("userLogin"))));

    }
}
